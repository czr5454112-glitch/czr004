#!/usr/bin/env bash
set -euo pipefail
cd /root/czr004
export PYTHONPATH="$PWD/src:$PWD/scripts:${PYTHONPATH:-}"
export REMOTE_ARTIFACT_ROOT=/root/shared-nvme/czr004_g559_remote_artifacts
export REPAIR5G_SKIP_AGGREGATE_JSONL=1
export REPAIR5G_STREAM_RESULT_CSV=1
ROWS="outputs/tables/phase5p5_repair5g560_labelv51_training_rows.csv"
CTX="/root/shared-nvme/czr004_g559_remote_artifacts/contexts"
BIN="build/phase1a-batch/phase1a_batch"
LOG="outputs/logs/phase5p5_repair5g565_tail_controller.log"
mkdir -p outputs/logs outputs/aborted
main_active() {
  ps -eo pid,cmd | grep -E 'run_g565_resume_after_mem\.sh|run_repair5g565_staged_scaling\.py|train_repair5g565_rich_cycle\.py|run_repair5g565_fresh_solver_panel\.py|run_repair5g565_alpha_response\.py|generate_repair5g565_context_expansion\.py|run_repair5g565_expanded_training\.py|run_repair5g565_expanded_solver_panel\.py|write_repair5g565_decision\.py|run_repair5g559_5090\.py|recover_repair5g560_labelv51\.py' | grep -v grep | grep -v phase5p5_repair5g565_tail_controller.sh >/dev/null
}
json_field() {
  python - "$1" "$2" <<'PY'
import json, sys
from pathlib import Path
p = Path(sys.argv[1]); key = sys.argv[2]
if not p.exists():
    print('')
else:
    print((json.loads(p.read_text()).get(key) or ''))
PY
}
need_fresh() {
  python - <<'PY'
import json, sys
from pathlib import Path
p=Path('outputs/reports/phase5p5_repair5g565_fresh_solver_panel_summary.json')
s=json.loads(p.read_text()) if p.exists() else {}
sys.exit(0 if s.get('fresh_solver_panel_ran') is True else 1)
PY
}
need_alpha() {
  python - <<'PY'
import json, sys
from pathlib import Path
p=Path('outputs/reports/phase5p5_repair5g565_alpha_response_summary.json')
s=json.loads(p.read_text()) if p.exists() else {}
sys.exit(0 if s.get('decision') else 1)
PY
}
expansion_ready() {
  [ "$(json_field outputs/reports/phase5p5_repair5g565_context_expansion_summary.json decision)" = "g565_context_expansion_manifest_ready" ]
}
expansion_blocked() {
  [ "$(json_field outputs/reports/phase5p5_repair5g565_context_expansion_summary.json decision)" = "g565_context_expansion_blocked_incomplete_scope" ]
}
expanded_training_done() {
  [ "$(json_field outputs/reports/phase5p5_repair5g565_expanded_training_summary.json decision)" = "g565_expanded_training_completed" ]
}
expanded_panel_done_or_not_needed() {
  python - <<'PY'
import json, sys
from pathlib import Path
exp=json.loads(Path('outputs/reports/phase5p5_repair5g565_context_expansion_summary.json').read_text()) if Path('outputs/reports/phase5p5_repair5g565_context_expansion_summary.json').exists() else {}
p=Path('outputs/reports/phase5p5_repair5g565_expanded_solver_panel_summary.json')
s=json.loads(p.read_text()) if p.exists() else {}
if exp.get('decision') != 'g565_context_expansion_manifest_ready':
    sys.exit(0 if s.get('decision') else 1)
sys.exit(0 if s.get('expanded_solver_panel_ran') is True and s.get('expanded_exact_materialization_passed') is True else 1)
PY
}
run_topup() {
  echo "[G565-tail] expansion_topup_required $(date -Is)" | tee -a "$LOG"
  STAMP="$(date +%Y%m%d_%H%M%S)"
  ARCHIVE="outputs/aborted/phase5p5_repair5g565_pre_expansion_bank_${STAMP}"
  mkdir -p "$ARCHIVE" /root/shared-nvme/czr004_g559_remote_artifacts/pre_g565_expansion_archive_${STAMP}
  cp -f "$ROWS" "$ARCHIVE/phase5p5_repair5g560_labelv51_training_rows.pre_expansion.csv" 2>/dev/null || true
  cp -f outputs/reports/phase5p5_repair5g560_labelv51_recovery_summary.json "$ARCHIVE/phase5p5_repair5g560_labelv51_recovery_summary.pre_expansion.json" 2>/dev/null || true
  mv /root/shared-nvme/czr004_g559_remote_artifacts/pair_rows/labelv5_pilot_results.csv /root/shared-nvme/czr004_g559_remote_artifacts/pre_g565_expansion_archive_${STAMP}/ 2>/dev/null || true
  mv /root/shared-nvme/czr004_g559_remote_artifacts/pair_rows/labelv5_pilot_results.raw.csv /root/shared-nvme/czr004_g559_remote_artifacts/pre_g565_expansion_archive_${STAMP}/ 2>/dev/null || true
  python scripts/run_repair5g559_5090.py \
    --pilot-instances 5000 \
    --candidates-per-instance 64 \
    --codebook-size 1024 \
    --row-limit 0 \
    --max-workers 12 \
    --topology-count 40 \
    --binary "$BIN"
  python scripts/recover_repair5g560_labelv51.py
  python scripts/generate_repair5g565_context_expansion.py --rows-path "$ROWS" --context-dir "$CTX" --target-contexts 5000 --max-manifest-contexts 1000
  python - <<'PY'
import json
from pathlib import Path
s=json.loads(Path('outputs/reports/phase5p5_repair5g565_context_expansion_summary.json').read_text())
print({'event':'g565_tail_expansion_after_topup','decision':s.get('decision'),'manifest_rows':s.get('manifest_rows'),'unique_physical_map_hashes':s.get('unique_physical_map_hashes'),'unique_map_families':s.get('unique_map_families'),'unique_agent_count_tiers':s.get('unique_agent_count_tiers'),'unique_budget_tiers':s.get('unique_budget_tiers'),'block_reasons':s.get('block_reasons')})
if s.get('decision') != 'g565_context_expansion_manifest_ready':
    raise SystemExit('G5.65 expansion top-up did not satisfy the fail-closed gate')
PY
}
{
  echo "[G565-tail] started $(date -Is)"
  while main_active; do
    echo "[G565-tail] main runner still active $(date -Is)"
    sleep 300
  done
  echo "[G565-tail] main runner inactive, auditing continuation $(date -Is)"
  if ! need_fresh; then
    echo "[G565-tail] running missing fresh solver panel $(date -Is)"
    python scripts/run_repair5g565_fresh_solver_panel.py --rows-path "$ROWS" --context-dir "$CTX" --contexts 1000 --checkpoint-glob 'artifacts/models/gcst/phase5p5_repair5g565_scaling_*_all_seed565.pt' 'artifacts/models/gcst/phase5p5_repair5g565_screening_scaling_e2_fold0_all_seed565.pt' 'artifacts/models/gcst/phase5p5_repair5g565_rich_cycle_*_merged_seed565.pt' --device cuda --batch-size 16 --max-workers 12 --overwrite
  fi
  if ! need_alpha; then
    echo "[G565-tail] running missing alpha response $(date -Is)"
    python scripts/run_repair5g565_alpha_response.py --rows-path "$ROWS" --context-dir "$CTX" --max-contexts 256
  fi
  echo "[G565-tail] refreshing expansion gate $(date -Is)"
  python scripts/generate_repair5g565_context_expansion.py --rows-path "$ROWS" --context-dir "$CTX" --target-contexts 5000 --max-manifest-contexts 1000
  if expansion_blocked; then
    run_topup
  fi
  if expansion_ready; then
    if ! expanded_training_done; then
      echo "[G565-tail] running expanded training $(date -Is)"
      python scripts/run_repair5g565_expanded_training.py --rows-path "$ROWS" --context-dir "$CTX" --max-contexts 1000 --epochs 100 --hidden-dim 64 --batch-size 16 --device cuda
    fi
  else
    echo "[G565-tail] expansion not ready; writing not-triggered expanded training artifact $(date -Is)"
    python scripts/run_repair5g565_expanded_training.py --rows-path "$ROWS" --context-dir "$CTX" --max-contexts 1000 --epochs 100 --hidden-dim 64 --batch-size 16 --device cuda
  fi
  if ! expanded_panel_done_or_not_needed; then
    echo "[G565-tail] running expanded solver panel / not-triggered artifact $(date -Is)"
    python scripts/run_repair5g565_expanded_solver_panel.py --rows-path "$ROWS" --context-dir "$CTX" --contexts 1000 --min-preferred-contexts 400 --device cuda --batch-size 16 --max-workers 12 --overwrite
  fi
  python scripts/write_repair5g565_decision.py
  echo "[G565-tail] done $(date -Is)"
} 2>&1 | tee -a "$LOG"
