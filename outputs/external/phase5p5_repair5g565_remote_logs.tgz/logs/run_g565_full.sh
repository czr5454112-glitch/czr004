#!/usr/bin/env bash
set -euo pipefail
cd /root/czr004
export PYTHONPATH=src
ROWS="outputs/tables/phase5p5_repair5g560_labelv51_training_rows.csv"
CTX="/root/shared-nvme/czr004_g559_remote_artifacts/contexts"
LOG="outputs/logs/phase5p5_repair5g565_tmux_full.log"
mkdir -p outputs/logs artifacts/models/gcst outputs/reports outputs/tables
{
  echo "[G565] final_evidence_completion_run $(date -Is)"
  echo "[G565] gpu: $(nvidia-smi --query-gpu=name,memory.total,memory.used --format=csv,noheader | head -1)"
  echo "[G565] context files: $(find "$CTX/scenarios" -type f | wc -l)"
  echo "[G565] rows bytes: $(stat -c%s "$ROWS")"
  echo "[G565] schedule: mem_contexts=64 mem_epochs=2 scaling_contexts=128 scaling_epochs=2 scaling_folds=4 scaling_seeds=565,566,567 fresh_contexts=1000 hidden_dim=32"
  python scripts/audit_repair5g565_g564_truth.py
  python scripts/run_repair5g565_loss_ablation.py --rows-path "$ROWS" --context-dir "$CTX" --max-contexts 1000 --max-ablation-contexts 256
  python scripts/calibrate_repair5g565_label_margin.py
  python scripts/run_repair5g565_neural_memorization.py --rows-path "$ROWS" --context-dir "$CTX" --max-contexts 64 --sizes 1,4,8,16,32 --architectures B1,B2,E0,E1,E2 --seeds 565,566,567 --epochs 2 --hidden-dim 32 --batch-size 64 --device cuda
  python scripts/run_repair5g565_current_bank_scaling.py --rows-path "$ROWS" --context-dir "$CTX" --max-contexts 128 --folds 4 --sizes 32,64,all --seeds 565,566,567 --methods B0,B1,B2,E0,E1 --epochs 2 --hidden-dim 32 --batch-size 64 --device cuda
  python scripts/train_repair5g565_rich_cycle.py --rows-path "$ROWS" --context-dir "$CTX" --max-contexts 128 --epochs 2 --hidden-dim 32 --batch-size 64 --device cuda
  python scripts/run_repair5g565_fresh_solver_panel.py --rows-path "$ROWS" --context-dir "$CTX" --contexts 1000 --checkpoint-glob 'artifacts/models/gcst/phase5p5_repair5g565_scaling_*_all_seed565.pt' 'artifacts/models/gcst/phase5p5_repair5g565_rich_cycle_*_merged_seed565.pt' --device cuda --batch-size 64 --max-workers 12 --overwrite
  python scripts/run_repair5g565_alpha_response.py --rows-path "$ROWS" --context-dir "$CTX" --max-contexts 256
  python scripts/generate_repair5g565_context_expansion.py --rows-path "$ROWS" --context-dir "$CTX" --target-contexts 5000 --max-manifest-contexts 1000
  python scripts/run_repair5g565_expanded_training.py --rows-path "$ROWS" --context-dir "$CTX" --max-contexts 128 --epochs 2 --hidden-dim 32 --batch-size 64 --device cuda
  python scripts/write_repair5g565_decision.py
  echo "[G565] done $(date -Is)"
} 2>&1 | tee -a "$LOG"
