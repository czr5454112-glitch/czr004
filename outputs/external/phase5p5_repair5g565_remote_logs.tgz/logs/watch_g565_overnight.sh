#!/usr/bin/env bash
set -u
cd /root/czr004 || exit 1
WATCH_LOG="outputs/logs/phase5p5_repair5g565_overnight_watchdog.log"
ALERT="outputs/reports/phase5p5_repair5g565_overnight_alert.txt"
MAIN_LOG="outputs/logs/phase5p5_repair5g565_tmux_resume_after_mem.log"
while true; do
  {
    echo "===== $(date -Is) ====="
    if tmux has-session -t g565 2>/dev/null; then
      echo "main_tmux=alive"
    else
      echo "main_tmux=missing"
      if [ ! -f outputs/reports/phase5p5_repair5g565_decision_summary.json ]; then
        echo "$(date -Is) main tmux missing before decision summary" >> "$ALERT"
      fi
    fi
    echo "processes:"
    ps -eo pid,etime,pcpu,pmem,stat,args | grep -E 'run_repair5g565_current_bank_scaling|run_repair5g565_staged_scaling|train_repair5g565|fresh_solver|run_g565_resume' | grep -v grep || true
    echo "gpu:"
    nvidia-smi --query-gpu=name,memory.used,memory.total,utilization.gpu --format=csv,noheader 2>/dev/null || true
    echo "disk:"
    df -h /root/czr004 /root/shared-nvme 2>/dev/null || true
    echo "progress:"
    python - <<'PY'
import json
from collections import Counter
from pathlib import Path
log=Path('outputs/logs/phase5p5_repair5g565_tmux_resume_after_mem.log')
sc=[]; dec=[]; cmds=[]
if log.exists():
    for line in log.read_text(errors='replace').splitlines():
        if '"event": "scaling"' in line:
            try: sc.append(json.loads(line))
            except Exception: pass
        if '"decision"' in line: dec.append(line)
        if 'staged_scaling_command' in line: cmds.append(line)
print({'scaling_events':len(sc),'by_size':dict(Counter(r.get('size') for r in sc)),'last':sc[-1] if sc else None,'commands':len(cmds),'decisions_tail':dec[-3:]})
PY
    echo "tail:"
    tail -n 8 "$MAIN_LOG" 2>/dev/null || true
  } >> "$WATCH_LOG" 2>&1
  sleep 600
done
