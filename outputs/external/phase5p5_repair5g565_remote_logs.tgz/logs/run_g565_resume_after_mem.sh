#!/usr/bin/env bash
set -euo pipefail
cd /root/czr004
export PYTHONPATH=src
export TORCH_ALLOW_TF32_CUBLAS_OVERRIDE=1
export PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True
ROWS="outputs/tables/phase5p5_repair5g560_labelv51_training_rows.csv"
CTX="/root/shared-nvme/czr004_g559_remote_artifacts/contexts"
LOG="outputs/logs/phase5p5_repair5g565_tmux_resume_after_mem.log"
mkdir -p outputs/logs artifacts/models/gcst outputs/reports outputs/tables
{
  echo "[G565] resume_after_valid_full_memorization $(date -Is)"
  echo "[G565] scientific_scope_downgraded=false"
  echo "[G565] checkpoint_resume=true"
  echo "[G565] zero_row_screening_run_excluded=true"
  echo "[G565] gpu: $(nvidia-smi --query-gpu=name,memory.total,memory.used --format=csv,noheader | head -1)"
  echo "[G565] scaling screening: folds=4 fold_indices=0 sizes=64,128,256,512,all methods=B0,B1,B2,E0,E1,E2 seeds=565,566,567 epochs=100 min=30 patience=10"
  echo "[G565] scaling confirmatory: folds=4 sizes=128,256,512,all methods=B0,B1,B2 + top2 rich seeds=565,566,567 epochs=100 min=30 patience=10"
  python - <<'PY'
import csv, json
from pathlib import Path
import torch
if torch.cuda.is_available():
    torch.backends.cuda.matmul.allow_tf32 = True
    torch.backends.cudnn.allow_tf32 = True
summary = json.loads(Path('outputs/reports/phase5p5_repair5g565_neural_memorization_summary.json').read_text())
rows = list(csv.DictReader(Path('outputs/tables/phase5p5_repair5g565_neural_memorization_runs.csv').open()))
assert summary.get('decision') == 'g565_neural_memorization_strong_pass', summary
assert len(rows) >= 80, len(rows)
print({'event':'resume_preflight','memorization_decision':summary.get('decision'),'memorization_rows':len(rows),'cuda':torch.cuda.is_available(),'tf32_matmul':getattr(torch.backends.cuda.matmul,'allow_tf32',None)})
PY
  python scripts/run_repair5g565_staged_scaling.py --rows-path "$ROWS" --context-dir "$CTX" --max-contexts 1000 --screening-epochs 100 --confirmatory-epochs 100 --min-epochs 30 --early-stop-patience 10 --hidden-dim 64 --batch-size 16 --device cuda --amp-bf16
  python scripts/train_repair5g565_rich_cycle.py --rows-path "$ROWS" --context-dir "$CTX" --max-contexts 1000 --epochs 100 --min-epochs 30 --early-stop-patience 10 --hidden-dim 64 --batch-size 16 --seeds 565,566,567 --device cuda --amp-bf16
  python scripts/run_repair5g565_fresh_solver_panel.py --rows-path "$ROWS" --context-dir "$CTX" --contexts 1000 --checkpoint-glob 'artifacts/models/gcst/phase5p5_repair5g565_scaling_*_all_seed565.pt' 'artifacts/models/gcst/phase5p5_repair5g565_screening_scaling_e2_fold0_all_seed565.pt' 'artifacts/models/gcst/phase5p5_repair5g565_rich_cycle_*_merged_seed565.pt' --device cuda --batch-size 16 --max-workers 12 --overwrite
  python scripts/run_repair5g565_alpha_response.py --rows-path "$ROWS" --context-dir "$CTX" --max-contexts 256
  python scripts/generate_repair5g565_context_expansion.py --rows-path "$ROWS" --context-dir "$CTX" --target-contexts 5000 --max-manifest-contexts 1000
  if python - <<'PYTOPUP'
import json, sys
from pathlib import Path
p = Path('outputs/reports/phase5p5_repair5g565_context_expansion_summary.json')
s = json.loads(p.read_text()) if p.exists() else {}
decision = s.get('decision')
print({'event': 'g565_expansion_gate_after_current_bank', 'decision': decision, 'block_reasons': s.get('block_reasons')})
sys.exit(75 if decision == 'g565_context_expansion_blocked_incomplete_scope' else 0)
PYTOPUP
  then
    echo "[G565] expansion_topup_not_required $(date -Is)"
  else
    rc=$?
    if [ "$rc" -ne 75 ]; then exit "$rc"; fi
    echo "[G565] expansion_topup_required $(date -Is)"
    STAMP="$(date +%Y%m%d_%H%M%S)"
    ARCHIVE="outputs/aborted/phase5p5_repair5g565_pre_expansion_bank_${STAMP}"
    mkdir -p "$ARCHIVE" /root/shared-nvme/czr004_g559_remote_artifacts/pre_g565_expansion_archive_${STAMP}
    cp -f outputs/tables/phase5p5_repair5g560_labelv51_training_rows.csv "$ARCHIVE/phase5p5_repair5g560_labelv51_training_rows.pre_expansion.csv" 2>/dev/null || true
    cp -f outputs/reports/phase5p5_repair5g560_labelv51_recovery_summary.json "$ARCHIVE/phase5p5_repair5g560_labelv51_recovery_summary.pre_expansion.json" 2>/dev/null || true
    mv /root/shared-nvme/czr004_g559_remote_artifacts/pair_rows/labelv5_pilot_results.csv /root/shared-nvme/czr004_g559_remote_artifacts/pre_g565_expansion_archive_${STAMP}/ 2>/dev/null || true
    mv /root/shared-nvme/czr004_g559_remote_artifacts/pair_rows/labelv5_pilot_results.raw.csv /root/shared-nvme/czr004_g559_remote_artifacts/pre_g565_expansion_archive_${STAMP}/ 2>/dev/null || true
    export REMOTE_ARTIFACT_ROOT=/root/shared-nvme/czr004_g559_remote_artifacts
    export REPAIR5G_SKIP_AGGREGATE_JSONL=1
    export REPAIR5G_STREAM_RESULT_CSV=1
    python scripts/run_repair5g559_5090.py       --pilot-instances 5000       --candidates-per-instance 64       --codebook-size 1024       --row-limit 0       --max-workers 12       --topology-count 40       --binary build/phase1a-batch/phase1a_batch
    python scripts/recover_repair5g560_labelv51.py
    python scripts/generate_repair5g565_context_expansion.py --rows-path "$ROWS" --context-dir "$CTX" --target-contexts 5000 --max-manifest-contexts 1000
    python - <<'PYTOPUPDONE'
import json
from pathlib import Path
p = Path('outputs/reports/phase5p5_repair5g565_context_expansion_summary.json')
s = json.loads(p.read_text())
print({'event': 'g565_expansion_gate_after_topup', 'decision': s.get('decision'), 'manifest_rows': s.get('manifest_rows'), 'unique_physical_map_hashes': s.get('unique_physical_map_hashes'), 'unique_map_families': s.get('unique_map_families'), 'unique_agent_count_tiers': s.get('unique_agent_count_tiers'), 'unique_budget_tiers': s.get('unique_budget_tiers'), 'block_reasons': s.get('block_reasons')})
if s.get('decision') != 'g565_context_expansion_manifest_ready':
    raise SystemExit('expansion top-up did not satisfy G5.65 gate')
PYTOPUPDONE
  fi

  python scripts/run_repair5g565_expanded_training.py --rows-path "$ROWS" --context-dir "$CTX" --max-contexts 1000 --epochs 100 --hidden-dim 64 --batch-size 16 --device cuda
  
python scripts/run_repair5g565_expanded_solver_panel.py \
  --rows-path outputs/tables/phase5p5_repair5g560_labelv51_training_rows.csv \
  --context-dir /root/shared-nvme/czr004_g559_remote_artifacts/contexts \
  --contexts 1000 \
  --min-preferred-contexts 400 \
  --device cuda \
  --batch-size 16 \
  --max-workers 12 \
  --overwrite

python scripts/write_repair5g565_decision.py
  echo "[G565] resume_done $(date -Is)"
} 2>&1 | tee -a "$LOG"
