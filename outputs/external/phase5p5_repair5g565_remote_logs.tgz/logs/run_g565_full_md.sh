#!/usr/bin/env bash
set -euo pipefail
cd /root/czr004
export PYTHONPATH=src
export TORCH_ALLOW_TF32_CUBLAS_OVERRIDE=1
export PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True
ROWS="outputs/tables/phase5p5_repair5g560_labelv51_training_rows.csv"
CTX="/root/shared-nvme/czr004_g559_remote_artifacts/contexts"
LOG="outputs/logs/phase5p5_repair5g565_tmux_full.log"
mkdir -p outputs/logs artifacts/models/gcst outputs/reports outputs/tables
{
  echo "[G565] full_md_staged_run $(date -Is)"
  echo "[G565] scientific_scope_downgraded=false"
  echo "[G565] aborted_reduced_runs_excluded=true"
  echo "[G565] gpu: $(nvidia-smi --query-gpu=name,memory.total,memory.used --format=csv,noheader | head -1)"
  echo "[G565] context files: $(find "$CTX/scenarios" -type f | wc -l)"
  echo "[G565] rows bytes: $(stat -c%s "$ROWS")"
  echo "[G565] memorization: sizes=1,4,8,16,32 arch=B1,B2,E0,E1,E2 seeds=565,566,567 hidden_dims=64,96 max_epochs=100 min_epochs=30 patience=10"
  echo "[G565] scaling screening: folds=1 sizes=64,128,256,512,all methods=B0,B1,B2,E0,E1,E2 seeds=565,566,567 epochs=100 min=30 patience=10"
  echo "[G565] scaling confirmatory: folds=4 sizes=128,256,512,all methods=B0,B1,B2 + top2 rich seeds=565,566,567 epochs=100 min=30 patience=10"
  python - <<'PY'
import torch
if torch.cuda.is_available():
    torch.backends.cuda.matmul.allow_tf32 = True
    torch.backends.cudnn.allow_tf32 = True
print({'event':'torch_flags','cuda':torch.cuda.is_available(),'tf32_matmul':getattr(torch.backends.cuda.matmul,'allow_tf32',None),'cudnn_tf32':getattr(torch.backends.cudnn,'allow_tf32',None)})
PY
  python scripts/audit_repair5g565_g564_truth.py
  python scripts/run_repair5g565_loss_ablation.py --rows-path "$ROWS" --context-dir "$CTX" --max-contexts 1000 --max-ablation-contexts 256
  python scripts/calibrate_repair5g565_label_margin.py
  python scripts/run_repair5g565_neural_memorization.py --rows-path "$ROWS" --context-dir "$CTX" --max-contexts 1000 --sizes 1,4,8,16,32 --architectures B1,B2,E0,E1,E2 --seeds 565,566,567 --epochs 100 --min-epochs 30 --early-stop-patience 10 --hidden-dims 64,96 --batch-size 16 --device cuda --amp-bf16
  python scripts/run_repair5g565_staged_scaling.py --rows-path "$ROWS" --context-dir "$CTX" --max-contexts 1000 --screening-epochs 100 --confirmatory-epochs 100 --min-epochs 30 --early-stop-patience 10 --hidden-dim 64 --batch-size 16 --device cuda --amp-bf16
  python scripts/train_repair5g565_rich_cycle.py --rows-path "$ROWS" --context-dir "$CTX" --max-contexts 1000 --epochs 100 --min-epochs 30 --early-stop-patience 10 --hidden-dim 64 --batch-size 16 --seeds 565,566,567 --device cuda --amp-bf16
  python scripts/run_repair5g565_fresh_solver_panel.py --rows-path "$ROWS" --context-dir "$CTX" --contexts 1000 --checkpoint-glob 'artifacts/models/gcst/phase5p5_repair5g565_scaling_*_all_seed565.pt' 'artifacts/models/gcst/phase5p5_repair5g565_screening_scaling_e2_fold0_all_seed565.pt' 'artifacts/models/gcst/phase5p5_repair5g565_rich_cycle_*_merged_seed565.pt' --device cuda --batch-size 16 --max-workers 12 --overwrite
  python scripts/run_repair5g565_alpha_response.py --rows-path "$ROWS" --context-dir "$CTX" --max-contexts 256
  python scripts/generate_repair5g565_context_expansion.py --rows-path "$ROWS" --context-dir "$CTX" --target-contexts 5000 --max-manifest-contexts 1000
  python scripts/run_repair5g565_expanded_training.py --rows-path "$ROWS" --context-dir "$CTX" --max-contexts 1000 --epochs 100 --hidden-dim 64 --batch-size 16 --device cuda
  python scripts/write_repair5g565_decision.py
  echo "[G565] done $(date -Is)"
} 2>&1 | tee -a "$LOG"
